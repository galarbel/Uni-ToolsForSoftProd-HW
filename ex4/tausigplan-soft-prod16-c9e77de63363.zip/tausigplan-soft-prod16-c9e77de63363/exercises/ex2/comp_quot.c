int compute_quotient(int x, int y) 
{
  int quotient;
  quotient = x / y;
  return quotient;
}
