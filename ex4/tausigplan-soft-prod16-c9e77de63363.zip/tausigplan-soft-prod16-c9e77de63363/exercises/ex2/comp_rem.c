int compute_remainder(int x, int y) 
{
  int remainder;
  remainder = x % y;
  return remainder;
}
