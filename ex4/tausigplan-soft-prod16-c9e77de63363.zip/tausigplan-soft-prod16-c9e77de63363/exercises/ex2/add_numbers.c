int add_numbers(int x, int y) 
{
  int sumOfTwoNumbers;
  sumOfTwoNumbers = firstNumber + secondNumber;
  return sumOfTwoNumbers;
}
