int puts(const char *s) { }

int main(int argc, char **argv) {
	if (argc >= 3)
	{
	  puts(argv[2]);	
	}
}
